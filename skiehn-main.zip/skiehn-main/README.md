# skiehn
n_spacing_updated2:
parses the ssages xml file and finds the difference between nitrogen positions with periodic boundary conditions. provides visual representation of bond oscillations between bonded nitrogen interacting with a ruthenium slab.

to_xyz:
parses the ssages xml file into xyz format for OVITO to easily read

to poscar:
parses the ssages xml file into POSCAR format for OVITO to easily read

vasprun_to_xyz:
parses output vasprun.xml files to xyz to visualize in OVITO
