system:
3CHCH radicals, 8H adsorbed, 6H2 gas
original_path:  /dfs7/elizaml4/dkamp/poly_catal/c2_ru001surf/5_3ethane_8H_system/2_3chch_8H_6H2/2_nvt1500/150fs
